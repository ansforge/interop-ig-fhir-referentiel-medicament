# ans.fhir.fr.ruim#0.1.0: Référentiel Unique de l'Interopérabilité du Médicament

## Pages

* [Accueil](index.md)
* [Vue d'ensemble](specifications_techniques.md)
* [Artifacts Summary](artifacts.md)
* [Téléchargements et usages](downloads.md)
* [Autres Ressources](autres_ressources.md)
* [Historique des versions](change-log.md)
* [Sécurité](securite.md)

## Resources

### CodeSystems

* [RUIM - Codes des propriétés médicament](CodeSystem-cs-ruim-property-codes.md)
* [Référentiel Unique d'Interopérabilité du Médicament (RUIM) Minimal - Pour usage de SESALI](CodeSystem-terminologie-minimal-ruim.md)

### ValueSets

* [RUIM - ValueSet des codes de propriétés médicament](ValueSet-vs-ruim-property-codes.md)

### Resource Profiles

* [Profil RUIM - CodeSystem médicament](StructureDefinition-profile-ruim-codesystem.md)

### ImplementationGuides

* [Référentiel Unique de l'Interopérabilité du Médicament](index.md)
