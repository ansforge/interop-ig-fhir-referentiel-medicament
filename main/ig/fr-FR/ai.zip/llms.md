# ans.fhir.fr.ruim#0.0.1: Référentiel Unique de l'Interopérabilité du Médicament(fr-FR)

## Pages

* [Accueil](index.md)
* [Téléchargements et usages](downloads.md)
* [Informations sur la traduction](translationinfo.md)
* [Autres Ressources](autres_ressources.md)
* [Artifacts Summary](artifacts.md)
* [Sécurité](securite.md)
* [Historique des versions](change-log.md)
* [Vue d'ensemble](specifications_techniques.md)

## Resources

### CodeSystems

* [MinimalRuim](CodeSystem-MinimalRuim.md)
* [RUIM - Codes des propriétés médicament](CodeSystem-cs-ruim-property-codes.md)

### ValueSets

* [RUIM - ValueSet des codes de propriétés médicament](ValueSet-vs-ruim-property-codes.md)

### Resource Profiles

* [Profil RUIM - CodeSystem médicament](StructureDefinition-profile-ruim-codesystem.md)

### ImplementationGuides

* [Référentiel Unique de l'Interopérabilité du Médicament](ImplementationGuide-ans.fhir.fr.ruim.md)
